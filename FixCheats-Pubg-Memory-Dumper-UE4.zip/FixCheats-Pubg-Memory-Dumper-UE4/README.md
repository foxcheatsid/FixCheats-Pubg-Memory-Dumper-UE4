# Pubg-Memory-Dumper
Hey this is free memory bdumper for making ESP for pubg mobile for Android

how to use it
#Root Device
copy this "foxcheats_class.py" file in to your root package of termux home folder ( /data/data/com.termux/files/home/<here> )


requirements install in termux

   you must install tsu -> pkg install tsu

   you must install python -> pkg install python

Clear, and next Run the game PUBG till lobby.  so that all files get loded
copy and paste this to termux and enter

           tsudo python ./foxcheats_class.py

that's all Done!

why we need this Dumped File?!

Because when anything loads in to system it gets decrypted for a while to load. hence by this we can load decrypted libUE4.so


libUE4.so Dump save in sdcard
